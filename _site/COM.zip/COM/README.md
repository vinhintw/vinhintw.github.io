A long-term scalable technology-enable solution to assist journey preparation for members of vision impaired community. The existing application allows users to familiarize themselves with a specific location in the CBD by letting them experience the immersive auditory-based simulator supported with state-of-the-art surround-sound technology called Ambisonic and dynamic interactive voice interface.

Blog post on this project: https://dunglai.github.io/2018/04/09/NavigationTrainer/

My contact: dunglai.github.io/About
